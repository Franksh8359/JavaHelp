/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pizzeria_franksholly;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.fxml.FXML;
import javafx.scene.control.ListView;
import java.sql.*;
import javafx.collections.ObservableList;
import javafx.collections.ListChangeListener;
import javafx.collections.FXCollections;
import javafx.scene.control.Button;

public class PizzeriaController {
    
    @FXML
    private Button button;

    @FXML
    private ListView<String> selectionListBox;

    @FXML
    void initialize(ActionEvent event) {

    }

    @FXML
    void loadButtonListener(ActionEvent event) {

    }
    public void initialize(){
        
        final String DB_URL = "jdbc:derby://localhost:1527/sample";
    
        try {
        Connection conn = DriverManager.getConnection(DB_URL);
        
        Statement stmt = conn.createStatement();
        String sqlStatement = "SELECT NAME FROM APP.CUSTOMER";
        ResultSet result = stmt.executeQuery(sqlStatement);
        while (result.next()) {selectionListBox.getItems().add(result.getString("NAME"));}
        conn.close();
            }
        catch(Exception ex) {selectionListBox.getItems().add("ERROR");}

    }
    
    public void loadButtonListener(){
//        final String DB_URL = "jdbc:derby:Pizza";
//    
//        try {
//        Connection conn = DriverManager.getConnection(DB_URL);
//        
//        Statement stmt = conn.createStatement();
//        String sqlStatement = "SELECT Topping FROM Toppings";
//        ResultSet result = stmt.executeQuery(sqlStatement);
//        while (result.next()) {selectionListBox.getItems().add(result.getString("Topping"));}
//        conn.close();
//            }
//        catch(Exception ex) {selectionListBox.getItems().add("ERROR");}
    }
    
}
